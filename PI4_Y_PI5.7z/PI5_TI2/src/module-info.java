module PI5_TI2 {
	
	requires transitive grafos;
	requires transitive partecomun;
}

