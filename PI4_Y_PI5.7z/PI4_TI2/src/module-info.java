/**
 * 
 */
/**
 * 
 */
module PI4_TI2 {
	requires transitive partecomun;
	requires transitive geneticos;
	requires transitive solve;
	
	exports datos;
}